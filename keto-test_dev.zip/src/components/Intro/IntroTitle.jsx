import React from 'react';

export class IntroTitle extends React.Component {
    render() {
        return (
            <h1 className="intro__title">Какой способ похудения подходит вам больше всего?</h1>
        );
    }
}