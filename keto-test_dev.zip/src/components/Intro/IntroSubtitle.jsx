import React from 'react';

export class IntroSubtitle extends React.Component {
    render() {
        return (
            <h2 className="intro__subtitle">Пройдите тест и получите рекомендации диетологов, разработанные с учетом ваших личных параметров и образа жизни.</h2>
        );
    }
}